﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MoneyMirror.Core.Models
{
    public class Child
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ChildID { get; set; }

        [Required]
        [MaxLength(50)]
        public string LoginCode { get; set; }

        [Required]
        [MaxLength(100)]
        public string FName { get; set; }

        [Required]
        [MaxLength(100)]
        public string LName { get; set; }

        [Required]
        public DateTime DOB { get; set; }

        [Required]
        public int Age { get; set; }

        [MaxLength(10)]
        public string? Gender { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal CurrentBalance { get; set; } = 0.00m;

        /// Indicates whether the personality profile has been finalized by AI analysis.
        /// False = using temporary "Pending Analysis" personality type
        /// True = real AI analysis has been completed and personality type is final
        /// This flag allows the app to function with placeholder data while AI team
        /// develops the real personality classification logic.
        [Required]
        public bool IsPersonalityFinalized { get; set; } = false;

        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public int? TypeID { get; set; }

        /// Selected character type (Nova, Luna, Cosmo, Aura).
        /// Foreign key to Character table.
        /// The space character this child has chosen.
        /// Null if child hasn't selected a character yet.
        /// </summary>
        public int? CharacterID { get; set; }

        // ==================== NAVIGATION PROPERTIES ====================
        // Add this to the navigation properties section

        /// <summary>
        /// Reference to the child's selected space character.
        /// </summary>
        [ForeignKey("CharacterID")]
        public virtual Character SelectedCharacter { get; set; }

        // ==================== AUTHENTICATION FIELDS ====================

        /// Long-lived refresh token for obtaining new access tokens.
        /// Generated during login, valid for 7 days.
        /// Used to refresh expired access tokens without re-login.
        /// Stored as hashed value for security.
        [MaxLength(500)]
        public string? RefreshToken { get; set; }

        /// Expiration timestamp for refresh token.
        /// Refresh tokens expire after 7 days.
        /// Child must log in again after expiration.
        public DateTime? RefreshTokenExpiry { get; set; }

        // ==================== NAVIGATION PROPERTIES ====================

        /// Reference to the child's personality type.
        /// Contains parent-facing and child-facing names, traits, and recommendations.
        [ForeignKey("TypeID")]
        public virtual PersonalityType? PersonalityType { get; set; }

        /// Collection of parent-child relationships.
        /// Uses ParentChild junction table for many-to-many relationship.
        /// One child can be managed by multiple parents (e.g., divorced parents).
        public virtual ICollection<ParentChild> ParentChildren { get; set; } = new List<ParentChild>();

        /// Collection of notifications sent to this child.
        /// Includes reminders to log expenses, goal progress updates, and encouragement.
        public virtual ICollection<Notification> Notifications { get; set; } = new List<Notification>();

        /// Collection of allowances given to this child.
        /// Includes both recurring allowances and one-time bonuses.
        public virtual ICollection<Allowance> Allowances { get; set; } = new List<Allowance>();

        /// Collection of savings goals created by or assigned to this child.
        /// Includes both child-created goals and parent challenge goals.
        public virtual ICollection<SavingsGoal> SavingsGoals { get; set; } = new List<SavingsGoal>();

        /// Collection of expenses logged by this child.
        /// Each expense includes amount, category, mood, and optional notes.
        public virtual ICollection<Expense> Expenses { get; set; } = new List<Expense>();

        /// Collection of quiz responses from interactive story quizzes.
        /// Used to refine personality profiling over time.
        public virtual ICollection<QuizLog> QuizLogs { get; set; } = new List<QuizLog>();

        /// Collection of achievements/badges earned by this child.
        /// Uses ChildAchievement junction table for many-to-many relationship.
        public virtual ICollection<ChildAchievement> ChildAchievements { get; set; } = new List<ChildAchievement>();

        /// One-to-one relationship with initial profiling questionnaire.
        /// Stores parent's responses during child account setup.
        public virtual InitialProfilingQuestionnaire? InitialProfilingQuestionnaire { get; set; }

        /// Collection of personalized advice entries for this child.
        /// Generated by AI based on spending patterns and personality type.
        public virtual ICollection<Advice> Advices { get; set; } = new List<Advice>();
        /// <summary>
        /// Collection of all financial transactions for this child.
        /// Includes allowances, bonuses, expenses, goal transfers.
        /// </summary>
        public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
    }
}